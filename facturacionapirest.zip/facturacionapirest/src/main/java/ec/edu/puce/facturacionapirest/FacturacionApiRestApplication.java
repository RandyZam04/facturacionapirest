package ec.edu.puce.facturacionapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturacionApiRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(FacturacionApiRestApplication.class, args);
    }

}